"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.workerManager = void 0;
type: module;
const child_process_1 = require("child_process");
const events_1 = require("events");
const path = __importStar(require("node:path"));
class WorkerManager extends events_1.EventEmitter {
    worker = null;
    requestQueue = [];
    inFlight = new Map();
    isProcessing = false; // (10) keep strictly serial for SPI
    correlationId = 0;
    config;
    refCount = 0;
    // (5) stdout line buffer to handle chunking
    stdoutBuffer = '';
    // Linger keep-alive across deploys
    // Linger disabled temporarily to avoid redeploy races
    lingerTimer = null;
    lingerMs = 0;
    // Stop gating to avoid overlapping workers during redeploy
    stopping = false;
    stoppingPromise = null;
    constructor(config) {
        super();
        this.config = config;
    }
    /**
     * Add a reference to this worker manager
     */
    addRef() {
        this.refCount++;
        this.debug(`Worker manager reference count: ${this.refCount}`);
        // Cancel pending linger stop if a new reference arrives
        // linger disabled
        // Don't start worker here - only start when first request comes in
    }
    /**
     * Remove a reference from this worker manager
     */
    removeRef() {
        this.refCount--;
        this.debug(`Worker manager reference count: ${this.refCount}`);
        if (this.refCount <= 0) {
            this.stopWorker();
        }
    }
    /**
     * Start the Python worker process
     */
    startWorker() {
        if (this.worker) {
            this.debug('Worker already running');
            return;
        }
        if (this.stopping && this.stoppingPromise) {
            this.debug('Worker is stopping; delaying start');
            // Defer start slightly; request() will ensure start before use
            return;
        }
        try {
            const p = path.join(__dirname, '..', 'python', 'waveSharePythonWorker.py');
            this.debug(`path: ${p}`);
            const args = ['-u', p];
            this.worker = (0, child_process_1.spawn)('python3', args, {
                stdio: ['pipe', 'pipe', 'pipe']
                // (2) cwd intentionally left default per user note
            });
            this.log('Python worker started');
            // Initialize ADC after worker starts
            setTimeout(() => {
                this.request({
                    jsonrpc: '2.0',
                    method: 'init_adc',
                    params: {}
                }).catch(error => {
                    this.log(`ADC initialization failed: ${error.message}`);
                });
            }, 100);
            // Handle stdout (responses from worker) with buffering (5)
            this.worker.stdout?.on('data', (data) => {
                this.handleWorkerOutput(data.toString());
            });
            // Handle stderr (logging from worker)
            this.worker.stderr?.on('data', (data) => {
                this.debug(`Worker stderr: ${data.toString().trim()}`);
            });
            // Handle worker exit
            this.worker.on('exit', (code, signal) => {
                this.log(`Worker exited with code ${code}, signal ${signal}`);
                this.worker = null;
                if (this.stopping && this.stoppingPromise) {
                    this.stopping = false;
                    const done = this.stoppingPromise;
                    this.stoppingPromise = null;
                    // Resolve async on next tick
                    setTimeout(() => {
                        try {
                            done.resolve?.();
                        }
                        catch { }
                    }, 0);
                }
                this.emit('workerExit', { code, signal });
                // Reject all pending requests
                this.rejectAllPending('Worker process exited');
            });
            this.worker.on('error', (error) => {
                this.log(`Worker error: ${error.message}`);
                this.emit('workerError', error);
                this.rejectAllPending(`Worker error: ${error.message}`);
            });
        }
        catch (error) {
            this.log(`Failed to start worker: ${error}`);
            throw error;
        }
    }
    /**
     * Stop the Python worker process
     * (3) Don't null the ref before we may force-kill
     */
    stopWorker() {
        const proc = this.worker;
        if (!proc)
            return;
        if (!this.stopping) {
            this.stopping = true;
            let resolveFn;
            this.stoppingPromise = new Promise((resolve) => { resolveFn = resolve; });
            this.stoppingPromise.resolve = resolveFn;
        }
        this.log('Stopping Python worker');
        // Send SIGTERM first
        proc.kill('SIGTERM');
        // Force kill after 2 seconds if still running
        setTimeout(() => {
            if (proc.exitCode === null) {
                this.log('Force killing worker');
                proc.kill('SIGKILL');
            }
        }, 2000);
    }
    /**
     * Handle output from the Python worker (5)
     */
    handleWorkerOutput(chunk) {
        this.stdoutBuffer += chunk;
        const lines = this.stdoutBuffer.split('\n');
        this.stdoutBuffer = lines.pop() ?? '';
        for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed)
                continue;
            try {
                const response = JSON.parse(trimmed);
                // Handle unsolicited stream events
                if (response && !response.id && response.method === 'stream_sample' && response.params) {
                    this.emit('stream', response.params);
                    continue;
                }
                this.handleWorkerResponse(response);
            }
            catch (error) {
                this.debug(`Failed to parse worker response: ${error?.message ?? String(error)} | line=${trimmed}`);
            }
        }
    }
    /**
     * Handle a response from the worker
     */
    handleWorkerResponse(response) {
        const { id, result, error } = response;
        this.debug(`worker response: id=${id}, hasResult=${result !== undefined}, hasError=${!!error}`);
        const pending = id ? this.inFlight.get(id) : undefined;
        if (!pending) {
            this.debug(`Received response for unknown request ID: ${id}`);
            return;
        }
        if (pending.timeout)
            clearTimeout(pending.timeout);
        this.inFlight.delete(id);
        if (error) {
            // (8) user controls error format; pass through message if present
            const msg = error?.message ?? String(error);
            pending.reject(new Error(`Worker error: ${msg}`));
        }
        else {
            pending.resolve(result);
        }
        // Mark processing complete and process next request in queue
        this.isProcessing = false;
        this.processNextRequest();
    }
    /**
     * Process the next request in the queue
     */
    processNextRequest() {
        if (this.isProcessing || (!this.requestQueue.length && this.inFlight.size > 0) || !this.worker) {
            return;
        }
        if (this.requestQueue.length === 0) {
            // Nothing to send
            return;
        }
        this.isProcessing = true; // (10) serial by design for SPI
        const queueItem = this.requestQueue.shift();
        try {
            const requestStr = JSON.stringify(queueItem.request) + '\n';
            const wrote = this.worker.stdin.write(requestStr); // (9) check backpressure
            // Track as in-flight and set timeout for this request
            const timeout = setTimeout(() => {
                const inflight = this.inFlight.get(queueItem.request.id);
                if (inflight) {
                    this.inFlight.delete(queueItem.request.id);
                    inflight.reject(new Error('Request timeout'));
                }
                this.isProcessing = false;
                this.processNextRequest();
            }, 10000);
            queueItem.timeout = timeout;
            this.inFlight.set(queueItem.request.id, queueItem);
            if (!wrote) {
                this.worker.stdin.once('drain', () => {
                    // nothing extra; already marked in-flight & timed
                    this.debug('stdin drained after backpressure');
                });
            }
        }
        catch (error) {
            this.log(`Failed to send request to worker: ${error}`);
            queueItem.reject(error);
            this.isProcessing = false;
            this.processNextRequest();
        }
    }
    /**
     * Send a request to the worker
     * (4) Start worker unconditionally if not running; refCount is lifecycle, not a hard gate
     */
    async request(request) {
        // If a stop is in progress, wait for it to complete to avoid overlap
        if (this.stopping && this.stoppingPromise) {
            this.debug('Awaiting worker stop before starting new worker');
            try {
                await this.stoppingPromise;
            }
            catch { }
        }
        if (!this.worker) {
            this.startWorker();
        }
        if (!this.worker) {
            throw new Error('Worker not running');
        }
        return new Promise((resolve, reject) => {
            const fullRequest = {
                ...request,
                id: `req_${++this.correlationId}`
            };
            const queueItem = {
                request: fullRequest,
                resolve,
                reject
            };
            this.requestQueue.push(queueItem);
            this.processNextRequest();
        });
    }
    /**
     * Read ADC channel and return converted result with config
     */
    async readADC(channel, options) {
        const params = {
            channel,
            gain: options?.gain ?? 1,
            drate: options?.drate ?? 10.0,
            differential: options?.differential ?? false,
            negChannel: options?.negChannel ?? 8,
            buffered: options?.buffered ?? false
        };
        const result = await this.request({
            jsonrpc: '2.0',
            method: 'read_adc',
            params
        });
        const ADC_VREF = 2.5; // 2.5V reference (hardwired LDO)
        const FSR = 2 * ADC_VREF; // Full Scale Range = +/- ADC_VREF = 5.0V
        const pga = params.gain;
        // Convert raw ADC value to millivolts
        // Formula: mV = 1000 * (raw/(2^23-1)) * (FSR/PGA)
        const mV = 1000 * (result.raw / (Math.pow(2, 23) - 1)) * (FSR / pga);
        return {
            channel: result.channel,
            raw: result.raw,
            mV: mV,
            config: {
                vref: ADC_VREF,
                pga: pga,
                sps: result.drate,
                buffered: result.buffered,
                differential: result.differential,
                negChannel: result.negChannel,
                timestamp: new Date().toISOString()
            }
        };
    }
    /**
     * Write DAC channel with voltage (converts to raw 16-bit value)
     */
    async writeDAC(channel, voltage) {
        const DAC_VREF = 2.5; // 2.5V reference
        // Clamp voltage to 0-2.5V range
        let clampedVoltage = voltage;
        if (clampedVoltage < 0) {
            clampedVoltage = 0;
        }
        else if (clampedVoltage > DAC_VREF) {
            clampedVoltage = DAC_VREF;
        }
        // Convert voltage to raw 16-bit value (DAC8532)
        const rawValue = Math.round(clampedVoltage * 65535 / DAC_VREF);
        await this.request({
            jsonrpc: '2.0',
            method: 'set_dac_value',
            params: {
                port: channel,
                value: rawValue
            }
        });
    }
    /**
     * Read multiple ADC channels based on definition
     */
    async readADCDefined(definition) {
        const result = await this.request({
            jsonrpc: '2.0',
            method: 'read_adc_defined',
            params: { definition }
        });
        return result;
    }
    /**
     * Send a ping request to check if worker is alive
     */
    async ping() {
        try {
            const result = await this.request({
                jsonrpc: '2.0',
                method: 'ping',
                params: {}
            });
            return result?.status === 'ok';
        }
        catch (error) {
            return false;
        }
    }
    /**
     * Check if the worker is connected
     * (7) Use exitCode instead of .killed
     */
    isConnected() {
        return !!(this.worker && this.worker.exitCode === null);
    }
    /**
     * Close the worker manager
     */
    close() {
        this.removeRef();
    }
    /**
     * Reject all pending requests
     */
    rejectAllPending(reason) {
        for (const [, pending] of this.inFlight) {
            if (pending.timeout)
                clearTimeout(pending.timeout);
            pending.reject(new Error(reason));
        }
        this.inFlight.clear();
        for (const queued of this.requestQueue) {
            if (queued.timeout)
                clearTimeout(queued.timeout);
            queued.reject(new Error(reason));
        }
        this.requestQueue = [];
        this.isProcessing = false;
    }
    /**
     * Log a message (11) separate log levels
     */
    log(message) {
        console.log(`[WorkerManager] ${message}`);
    }
    debug(message) {
        // Toggle with env or config flag if desired
        console.debug(`[WorkerManager:debug] ${message}`);
    }
}
// Export singleton instance - but don't start worker until first use
exports.workerManager = new WorkerManager({});
//# sourceMappingURL=worker-manager.js.map