import spidev
import RPi.GPIO as GPIO
import time
import signal
import sys
import atexit
import json
import logging
import threading
import subprocess
import os
from typing import Dict, Any, Optional, List, Tuple
from queue import Queue, Empty
from dataclasses import dataclass

# Import the working ADS1256 class
from waveSharePython import ADS1256 as WorkingADS1256


# Pin definition
RST_PIN = 18
CS_PIN = 22
DRDY_PIN = 17
ADC_VREF = 2.50

# SPI device, bus = 0, device = 0
SPI = spidev.SpiDev(0, 0)

# Global cleanup function
def _global_gpio_cleanup():
    """Global GPIO cleanup function"""
    try:
        GPIO.cleanup()
    except:
        pass  # Ignore cleanup errors

# Register cleanup handlers
atexit.register(_global_gpio_cleanup)


class ADC_Config:
    RST_PIN = RST_PIN
    CS_PIN = CS_PIN
    DRDY_PIN = DRDY_PIN
    
    def digital_write(pin, value):
        GPIO.output(pin, value)

    def digital_read(pin):
        return GPIO.input(DRDY_PIN)

    def delay_ms(delaytime):
        time.sleep(delaytime // 1000.0)

    def spi_writebyte(data):
        SPI.writebytes(data)
        
    def spi_readbytes(reg):
        return SPI.readbytes(reg)
        

    def module_init():
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        GPIO.setup(RST_PIN, GPIO.OUT)
        GPIO.setup(CS_PIN, GPIO.OUT)
        #GPIO.setup(DRDY_PIN, GPIO.IN)
        GPIO.setup(DRDY_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        SPI.max_speed_hz = 1000000
        SPI.mode = 0b01
        return 0;



ScanMode = 0


# gain channel
ADS1256_GAIN_E = {'ADS1256_GAIN_1' : 0, # GAIN   1
                  'ADS1256_GAIN_2' : 1,	# GAIN   2
                  'ADS1256_GAIN_4' : 2,	# GAIN   4
                  'ADS1256_GAIN_8' : 3,	# GAIN   8
                  'ADS1256_GAIN_16' : 4,# GAIN  16
                  'ADS1256_GAIN_32' : 5,# GAIN  32
                  'ADS1256_GAIN_64' : 6,# GAIN  64
                 }

# data rate
ADS1256_DRATE_E = {'ADS1256_30000SPS' : 0xF0, # reset the default values
                   'ADS1256_15000SPS' : 0xE0,
                   'ADS1256_7500SPS' : 0xD0,
                   'ADS1256_3750SPS' : 0xC0,
                   'ADS1256_2000SPS' : 0xB0,
                   'ADS1256_1000SPS' : 0xA1,
                   'ADS1256_500SPS' : 0x92,
                   'ADS1256_100SPS' : 0x82,
                   'ADS1256_60SPS' : 0x72,
                   'ADS1256_50SPS' : 0x63,
                   'ADS1256_30SPS' : 0x53,
                   'ADS1256_25SPS' : 0x43,
                   'ADS1256_15SPS' : 0x33,
                   'ADS1256_10SPS' : 0x20,
                   'ADS1256_5SPS' : 0x13,
                   'ADS1256_2d5SPS' : 0x03
                  }

# registration definition
REG_E = {'REG_STATUS' : 0,  # x1H
         'REG_MUX' : 1,     # 01H
         'REG_ADCON' : 2,   # 20H
         'REG_DRATE' : 3,   # F0H
         'REG_IO' : 4,      # E0H
         'REG_OFC0' : 5,    # xxH
         'REG_OFC1' : 6,    # xxH
         'REG_OFC2' : 7,    # xxH
         'REG_FSC0' : 8,    # xxH
         'REG_FSC1' : 9,    # xxH
         'REG_FSC2' : 10,   # xxH
        }

# command definition
CMD = {'CMD_WAKEUP' : 0x00,     # Completes SYNC and Exits Standby Mode 0000  0000 (00h)
       'CMD_RDATA' : 0x01,      # Read Data 0000  0001 (01h)
       'CMD_RDATAC' : 0x03,     # Read Data Continuously 0000   0011 (03h)
       'CMD_SDATAC' : 0x0F,     # Stop Read Data Continuously 0000   1111 (0Fh)
       'CMD_RREG' : 0x10,       # Read from REG rrr 0001 rrrr (1xh)
       'CMD_WREG' : 0x50,       # Write to REG rrr 0101 rrrr (5xh)
       'CMD_SELFCAL' : 0xF0,    # Offset and Gain Self-Calibration 1111    0000 (F0h)
       'CMD_SELFOCAL' : 0xF1,   # Offset Self-Calibration 1111    0001 (F1h)
       'CMD_SELFGCAL' : 0xF2,   # Gain Self-Calibration 1111    0010 (F2h)
       'CMD_SYSOCAL' : 0xF3,    # System Offset Calibration 1111   0011 (F3h)
       'CMD_SYSGCAL' : 0xF4,    # System Gain Calibration 1111    0100 (F4h)
       'CMD_SYNC' : 0xFC,       # Synchronize the A/D Conversion 1111   1100 (FCh)
       'CMD_STANDBY' : 0xFD,    # Begin Standby Mode 1111   1101 (FDh)
       'CMD_RESET' : 0xFE,      # Reset to Power-Up Values 1111   1110 (FEh)
       'CMD_WREG' : 0x50,       # Write to register
      }

class ADS1256:
    def __init__(self):
        self.rst_pin = ADC_Config.RST_PIN
        self.cs_pin = ADC_Config.CS_PIN
        self.drdy_pin = ADC_Config.DRDY_PIN

    # Hardware reset
    def ADS1256_reset(self):
        ADC_Config.digital_write(self.rst_pin, GPIO.HIGH)
        ADC_Config.delay_ms(200)
        ADC_Config.digital_write(self.rst_pin, GPIO.LOW)
        ADC_Config.delay_ms(200)
        ADC_Config.digital_write(self.rst_pin, GPIO.HIGH)
    
    def ADS1256_WriteCmd(self, reg):
        ADC_Config.digital_write(self.cs_pin, GPIO.LOW)#cs  0
        ADC_Config.spi_writebyte([reg])
        ADC_Config.digital_write(self.cs_pin, GPIO.HIGH)#cs 1
    
    def ADS1256_WriteReg(self, reg, data):
        self.ADS1256_WaitDRDY();
        ADC_Config.digital_write(self.cs_pin, GPIO.LOW)#cs  0
        ADC_Config.spi_writebyte([CMD['CMD_WREG'] | reg, 0x00, data])
        ADC_Config.digital_write(self.cs_pin, GPIO.HIGH)#cs 1
        
    def ADS1256_Read_data(self, reg):
        ADC_Config.digital_write(self.cs_pin, GPIO.LOW)#cs  0
        ADC_Config.spi_writebyte([CMD['CMD_RREG'] | reg, 0x00])
        data = ADC_Config.spi_readbytes(1)
        ADC_Config.digital_write(self.cs_pin, GPIO.HIGH)#cs 1

        return data
        
    def ADS1256_WaitDRDY(self):
        for i in range(0,400000,1):
            if(ADC_Config.digital_read(self.drdy_pin) == 0):
                
                break
        if(i >= 400000):
            print ("Time Out ...\r\n")
        
    def ADS1256_ReadChipID(self):
        self.ADS1256_WaitDRDY()
        id = self.ADS1256_Read_data(REG_E['REG_STATUS'])
        id = id[0] >> 4
        # print 'ID',id
        return id
        
    #The configuration parameters of ADC, gain and data rate
    def ADS1256_ConfigADC(self, gain, drate):
        self.ADS1256_WaitDRDY()
        buf = [0,0,0,0,0,0,0,0]
        buf[0] = (0<<3) | (1<<2) | (0<<1)
        buf[1] = 0x08
        buf[2] = (0<<5) | (0<<3) | (gain<<0)
        buf[3] = drate
        
        ADC_Config.digital_write(self.cs_pin, GPIO.LOW)#cs  0
        ADC_Config.spi_writebyte([CMD['CMD_WREG'] | 0, 0x03])
        ADC_Config.spi_writebyte(buf)
        
        ADC_Config.digital_write(self.cs_pin, GPIO.HIGH)#cs 1
        ADC_Config.delay_ms(1) 



    def ADS1256_SetChannel(self, Channel):
        if Channel > 7:
            return 0
        self.ADS1256_WaitDRDY();
        self.ADS1256_WriteReg(REG_E['REG_MUX'], (Channel<<4) | (1<<3))

    def ADS1256_SetDiffChannel(self, pos_channel, neg_channel):
        """Set differential channel pair - any valid pair per ADS1256 datasheet"""
        # Validate channel ranges (0-7 for ADS1256)
        if not (0 <= pos_channel <= 7) or not (0 <= neg_channel <= 7):
            raise ValueError("Channel numbers must be between 0 and 7")
        
        # MUX register: PSEL[3:0] in bits 7-4, NSEL[3:0] in bits 3-0
        mux_value = (pos_channel << 4) | neg_channel
        print(f"DEBUG: Setting differential pair AIN{pos_channel}-AIN{neg_channel}, MUX=0x{mux_value:02X}")
        self.ADS1256_WaitDRDY();

        self.ADS1256_WriteReg(REG_E['REG_MUX'], mux_value)

    def ADS1256_SetMode(self, Mode):
        ScanMode = Mode

    def ADS1256_init(self):
        # Force ownership of required pins
        try:
            self._force_pin_ownership()
        except Exception as e:
            print(f"Failed to force pin ownership: {e}")
            return -1
        
        # Perform hardware reset to ensure clean state
        self._hardware_reset()
        
        if (ADC_Config.module_init() != 0):
            return -1
        self.ADS1256_reset()
        id = self.ADS1256_ReadChipID()
        if id == 3 :
            print("ID Read success  ")
        else:
            print("ID Read failed   ")
            return -1
        self.ADS1256_ConfigADC(ADS1256_GAIN_E['ADS1256_GAIN_1'], ADS1256_DRATE_E['ADS1256_30000SPS'])
        return 0
        
    def ADS1256_Read_ADC_Data(self):
        self.ADS1256_WaitDRDY()
        ADC_Config.digital_write(self.cs_pin, GPIO.LOW)#cs  0
        ADC_Config.spi_writebyte([CMD['CMD_RDATA']])
        ADC_Config.delay_ms(15)

        buf = ADC_Config.spi_readbytes(3)
        ADC_Config.digital_write(self.cs_pin, GPIO.HIGH)#cs 1
        read = (buf[0]<<16) & 0xff0000
        read |= (buf[1]<<8) & 0xff00
        read |= (buf[2]) & 0xff
        if read & 0x800000:  # negative value
            read -= 1 << 24  # sign extend from 24 bits

        return read
 
    def ADS1256_GetChannelValue(self, Channel, neg_channel=None):
        if neg_channel is not None:
            # Differential mode - follow datasheet sequence
            if Channel >= 8 or neg_channel >= 8:
                return 0
            print(f"DEBUG: Reading differential AIN{Channel}-AIN{neg_channel}")
            
            # Step 2: Use WREG command to change MUX register
            mux_value = (Channel << 4) | neg_channel
            print(f"DEBUG: Setting differential pair AIN{Channel}-AIN{neg_channel}, MUX=0x{mux_value:02X}")
            self.ADS1256_WriteReg(REG_E['REG_MUX'], mux_value)
            
            # Step 3: Issue SYNC command immediately
            self.ADS1256_WriteCmd(CMD['CMD_SYNC'])
            
            # Step 4: Issue WAKEUP command (with timing t11)
            ADC_Config.delay_ms(1)  # t11 timing
            self.ADS1256_WriteCmd(CMD['CMD_WAKEUP'])
            
            # Step 6: Read data
            Value = self.ADS1256_Read_ADC_Data()
            print(f"DEBUG: Differential raw value: {Value}")
        else:
            # Single-ended mode - similar sequence
            if Channel >= 8:
                return 0
            print(f"DEBUG: Reading single-ended AIN{Channel}")
            
            # Wait for DRDY
            
            # Use WREG to set MUX
            mux_value = (Channel << 4) | 0x08  # Single-ended to AINCOM
            self.ADS1256_WriteReg(REG_E['REG_MUX'], mux_value)
            
            # SYNC/WAKEUP sequence
            self.ADS1256_WriteCmd(CMD['CMD_SYNC'])
            ADC_Config.delay_ms(1)
            self.ADS1256_WriteCmd(CMD['CMD_WAKEUP'])
            
            Value = self.ADS1256_Read_ADC_Data()
            print(f"DEBUG: Single-ended raw value: {Value}")
        
        
        return Value
        
    def ADS1256_GetAll(self):
        ADC_Value = [0,0,0,0,0,0,0,0]
        for i in range(0,8,1):
            ADC_Value[i] = self.ADS1256_GetChannelValue(i)
        return ADC_Value
        
    def _force_pin_ownership(self):
        """Force ownership of ADC pins by overriding any existing allocations"""
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        
        # Multiple cleanup attempts to ensure pins are freed
        for _ in range(3):
            try:
                GPIO.cleanup()
            except:
                pass
            time.sleep(0.01)
        
        # Force allocate pins - this will override any existing allocations
        GPIO.setup(self.cs_pin, GPIO.OUT, initial=GPIO.HIGH)
        GPIO.setup(self.drdy_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        GPIO.setup(self.rst_pin, GPIO.OUT, initial=GPIO.HIGH)
        
        print(f"Forced ADC pin ownership: CS={self.cs_pin}, DRDY={self.drdy_pin}, RST={self.rst_pin}")
        return True
    
    def _hardware_reset(self):
        """Perform hardware reset by holding RST pin low"""
        try:
            # Force cleanup first
            GPIO.cleanup()
            time.sleep(0.01)
            
            # Set up RST pin for reset
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(self.rst_pin, GPIO.OUT)
            
            # Perform hardware reset
            GPIO.output(self.rst_pin, GPIO.LOW)
            time.sleep(0.1)  # Hold reset for 100ms
            GPIO.output(self.rst_pin, GPIO.HIGH)
            time.sleep(0.1)  # Wait for reset to complete
            
            print("Hardware reset completed")
        except Exception as e:
            print(f"Hardware reset failed: {e}")
        
    
    def ADS1256_cleanup(self):
        """Clean up GPIO pins and SPI resources"""
        GPIO.cleanup()
        
    def ADS1256_GetDefined(self, definition):
        """
        Read ADC channels based on JSON definition
        definition: JSON object with array of channel definitions
        Each definition object contains: {channel, differential, neg-channel (if differential), buffered, SPS, gain}
        """
        import json
        
        # Parse JSON if it's a string, otherwise use as-is
        if isinstance(definition, str):
            definition = json.loads(definition)
        
        results = []
        
        for channel_def in definition:
            channel = channel_def.get('channel', 0)
            differential = channel_def.get('differential', False)
            neg_channel = channel_def.get('neg-channel', 1)
            buffered = channel_def.get('buffered', False)
            sps = channel_def.get('SPS', 10)
            gain = channel_def.get('gain', 1)
            
            # Configure ADC for this channel
            self.ADS1256_ConfigADC(ADS1256_GAIN_E[f'ADS1256_GAIN_{gain}'], ADS1256_DRATE_E[f'ADS1256_{sps}SPS'])
            
            
            # Read the channel using the proven GetChannelValue method
            if differential:
                raw_value = self.ADS1256_GetChannelValue(channel, neg_channel)
            else:
                raw_value = self.ADS1256_GetChannelValue(channel)
            
            # Calculate voltage (using the working formula from the original code)
            # Gain affects the full scale range, so divide by gain
            voltage = (raw_value * 5.0 / 0x7fffff) / gain
            
            result = {
                'channel': channel,
                'differential': differential,
                'negChannel': neg_channel if differential else None,
                'buffered': buffered,
                'sps': sps,
                'gain': gain,
                'raw': raw_value,
                'voltage': voltage
            }
            
            results.append(result)
        
        return results

# -----------------------------
# Logging to STDERR (Node reads responses from STDOUT)
# -----------------------------
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stderr)]
)
log = logging.getLogger(__name__)

# -----------------------------
# Config / Constants
# -----------------------------
@dataclass
class WorkerConfig:
    # GPIO (BCM numbering) as per Waveshare High-Precision AD/DA HAT silk
    adc_cs_pin: int = 22
    adc_rst_pin: int = 18
    adc_drdy_pin: int = 17
    dac_cs_pin: int = 23

    spi_bus: int = 0
    spi_dev: int = 0
    spi_speed_hz: int = 1_200_000  # Pi 4B-friendly default; overridable via WS_SPI_HZ

    # Watchdog & timeouts
    idle_shutdown_s: int = 300      # generous; worker stays alive while busy
    request_timeout_s: int = 10     # per-request guard

    # GPIO init retry policy
    gpio_init_retries: int = 3
    gpio_retry_delay_s: float = 0.05


class SPIResourceManager:
    def __init__(self, cfg: WorkerConfig):
        self.cfg = cfg
        self.spi: Optional[spidev.SpiDev] = None
        self.gpio_ready = False
        self.lock = threading.Lock()

    # Force GPIO ownership - override any existing allocations
    def _force_gpio_ownership(self) -> None:
        """Force ownership of required GPIO pins by overriding any existing allocations"""
        try:
            # Multiple cleanup attempts to ensure pins are freed
            for _ in range(3):
                try:
                    GPIO.cleanup()
                except:
                    pass
                time.sleep(0.01)
            
            # Set mode and disable warnings
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            
            # Force allocate pins - this will override any existing allocations
            GPIO.setup(self.cfg.adc_cs_pin, GPIO.OUT, initial=GPIO.HIGH)
            GPIO.setup(self.cfg.adc_rst_pin, GPIO.OUT, initial=GPIO.HIGH)
            GPIO.setup(self.cfg.adc_drdy_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            GPIO.setup(self.cfg.dac_cs_pin, GPIO.OUT, initial=GPIO.HIGH)
            
            log.info(f"Forced GPIO ownership: ADC_CS={self.cfg.adc_cs_pin}, ADC_RST={self.cfg.adc_rst_pin}, DRDY={self.cfg.adc_drdy_pin}, DAC_CS={self.cfg.dac_cs_pin}")
            
        except Exception as e:
            log.error(f"Failed to force GPIO ownership: {e}")
            raise RuntimeError(f"Could not claim required GPIO pins: {e}")

    # Lazily set up GPIO on first use
    def _setup_gpio(self) -> bool:
        if self.gpio_ready:
            return True
        try:
            self._force_gpio_ownership()
            self.gpio_ready = True
            return True
        except Exception as e:
            log.error(f"GPIO setup failed: {e}")
            return False

    def ensure_gpio_ready(self) -> None:
        """Ensure GPIO is initialized, forcing ownership if needed."""
        if self._setup_gpio():
            return
        
        # Force ownership - this will override any existing allocations
        try:
            self._force_gpio_ownership()
            self.gpio_ready = True
        except Exception as e:
            raise RuntimeError(f"Could not force GPIO ownership: {e}")

    # Lazily set up SPI on first use
    def _setup_spi(self) -> None:
        if self.spi is not None:
            return
        try:
            s = spidev.SpiDev()
            s.open(self.cfg.spi_bus, self.cfg.spi_dev)
            # Default to ADC-friendly speed; individual ops may override
            try:
                env_hz = int(os.environ.get("WS_SPI_HZ", "0"))
            except Exception:
                env_hz = 0
            s.max_speed_hz = env_hz if env_hz > 0 else self.cfg.spi_speed_hz
            s.mode = 0b01
            s.lsbfirst = False
            s.cshigh = False
            s.no_cs = True  # we drive CS on GPIO to avoid CE0 auto toggling
            self.spi = s
            log.info(
                f"SPI open bus={self.cfg.spi_bus}, dev={self.cfg.spi_dev}, "
                f"speed={self.spi.max_speed_hz}Hz, mode=1, no_cs=True"
            )
        except Exception as e:
            log.error(f"SPI open failed: {e}")
            raise

    def set_speed(self, hz: int) -> None:
        """Set SPI clock for the next operation."""
        if self.spi is None:
            self._setup_spi()
        try:
            self.spi.max_speed_hz = hz
        except Exception as e:
            log.warning(f"Failed to set SPI speed to {hz}: {e}")

    def cleanup(self) -> None:
        with self.lock:
            # Close SPI first
            if self.spi is not None:
                try:
                    self.spi.close()
                except Exception:
                    pass
                self.spi = None
            
            # Ensure CS pins are set high before cleanup
            if self.gpio_ready:
                try:
                    GPIO.output(self.cfg.adc_cs_pin, GPIO.HIGH)
                    GPIO.output(self.cfg.dac_cs_pin, GPIO.HIGH)
                except Exception:
                    pass
            
            # Cleanup GPIO pins
            if self.gpio_ready:
                try:
                    GPIO.cleanup()
                except Exception:
                    pass
                self.gpio_ready = False
            
            log.info("SPI/GPIO cleaned up - CS pins freed")


class DAC8532:
    def __init__(self, rm: SPIResourceManager, cfg: WorkerConfig):
        self.rm = rm
        self.cfg = cfg

    def set_value(self, port: int, value: int) -> Dict[str, Any]:
        if port not in (0, 1):
            raise ValueError("port must be 0 or 1")
        if not (0 <= value <= 0xFFFF):
            raise ValueError("value must be 0..65535")
        # Serialize DAC ops with ADC via shared lock
        with self.rm.lock:
            self.rm.ensure_gpio_ready()
            self.rm._setup_spi()

        # Match working da.py: 20kHz, mode=1
        cmd = 0x30 if port == 0 else 0x34
        hi = (value >> 8) & 0xFF
        lo = value & 0xFF
        GPIO.output(self.cfg.dac_cs_pin, GPIO.LOW)
        try:
            self.rm.spi.writebytes([cmd, hi, lo])
        finally:
            GPIO.output(self.cfg.dac_cs_pin, GPIO.HIGH)
        return {"port": port, "value": value}

    def set_voltage(self, port: int, voltage: float, vref: float = 5.0) -> Dict[str, Any]:
        if not (0.0 <= voltage <= vref):
            raise ValueError(f"voltage must be 0..{vref}V")
        value = int(round((voltage / vref) * 65535))
        out = self.set_value(port, value)
        out["voltage_mv"] = int(voltage * 1000)
        out["vref"] = vref
        return out

    def get_voltage_for_value(self, value: int, vref: float = 5.0) -> float:
        """Get voltage output for a given DAC value"""
        if not (0 <= value <= 65535):
            raise ValueError("value must be 0-65535")
        return (value / 65535.0) * vref

    def get_value_for_voltage(self, voltage: float, vref: float = 5.0) -> int:
        """Get DAC value for a given voltage"""
        if not (0.0 <= voltage <= vref):
            raise ValueError(f"voltage must be 0..{vref}V")
        return int(round((voltage / vref) * 65535))


# -----------------------------
# Worker (JSON-RPC stdio)
# -----------------------------
class Worker:
    def __init__(self, cfg: WorkerConfig):
        self.cfg = cfg
        self.rm = SPIResourceManager(cfg)
        self.dac = DAC8532(self.rm, cfg)
        self.adc = WorkingADS1256()  # Use the working ADS1256 class

        self.running = True
        self.last_activity = time.time()
        self.in_progress = threading.Event()
        
        signal.signal(signal.SIGINT, self._sig)
        signal.signal(signal.SIGTERM, self._sig)
        
        self.watchdog_t = threading.Thread(target=self._watchdog, daemon=True)
        self.watchdog_t.start()

        # Streaming state
        self.stream_running = False
        self.stream_cfg: Optional[Dict[str, Any]] = None
        self.stream_thread: Optional[threading.Thread] = None
        
    def _sig(self, signum, _frame):
        log.info(f"Signal {signum}; shutting down")
        self.running = False
        # Clean up GPIO on signal
        try:
            self.rm.cleanup()
            # Also cleanup ADC pins directly
            if hasattr(self, 'adc') and self.adc:
                self.adc.ADS1256_cleanup()
        except:
            pass
        
    def _tick(self):
        self.last_activity = time.time()

    def _watchdog(self):
        while self.running:
            time.sleep(1)
            if self.in_progress.is_set():
                self._tick()
                continue
            if time.time() - self.last_activity > self.cfg.idle_shutdown_s:
                log.info(f"No activity for {self.cfg.idle_shutdown_s}s, shutting down")
                self.running = False
                break
                
    def _with_timeout(self, fn, timeout_s: float, *a, **kw) -> Tuple[Any, Optional[Exception]]:
        box: Dict[str, Any] = {}
        err: Dict[str, Exception] = {}

        def target():
            try:
                box["ret"] = fn(*a, **kw)
            except Exception as e:
                err["e"] = e

        t = threading.Thread(target=target, daemon=True)
        t.start()
        t.join(timeout_s)
        if t.is_alive():
            return None, TimeoutError(f"operation timed out after {timeout_s}s")
        if "e" in err:
            return None, err["e"]
        return box.get("ret"), None

    def _write_response(self, resp: Dict[str, Any]) -> None:
        sys.stdout.write(json.dumps(resp) + "\n")
        sys.stdout.flush()

    def handle(self, req: Dict[str, Any]) -> Dict[str, Any]:
        self._tick()
        method = req.get("method")
        params = req.get("params") or {}
        _id = req.get("id")

        try:
            if method == "ping":
                return {"jsonrpc": "2.0", "id": _id, "result": {"status": "ok", "ts": time.time()}}
            
            if method == "init_adc":
                # Initialize ADC with forced GPIO allocation
                try:
                    init_result = self.adc.ADS1256_init()
                    if init_result == 0:
                        return {"jsonrpc": "2.0", "id": _id, "result": {"status": "ok", "message": "ADC initialized successfully"}}
                    else:
                        return {"jsonrpc": "2.0", "id": _id, "error": {"code": -32000, "message": "ADC initialization failed"}}
                except Exception as e:
                    return {"jsonrpc": "2.0", "id": _id, "error": {"code": -32000, "message": f"ADC init error: {e}"}}
            
            if method == "set_dac_value":
                ret = self.dac.set_value(int(params["port"]), int(params["value"]))
                return {"jsonrpc": "2.0", "id": _id, "result": ret}

            if method == "set_dac_voltage":
                ret = self.dac.set_voltage(int(params["port"]), float(params["voltage"]), float(params.get("vref", 5.0)))
                return {"jsonrpc": "2.0", "id": _id, "result": ret}

            if method == "get_dac_voltage_for_value":
                value = int(params["value"])
                vref = float(params.get("vref", 5.0))
                voltage = self.dac.get_voltage_for_value(value, vref)
                return {"jsonrpc": "2.0", "id": _id, "result": {"value": value, "voltage": voltage, "vref": vref}}

            if method == "get_dac_value_for_voltage":
                voltage = float(params["voltage"])
                vref = float(params.get("vref", 5.0))
                value = self.dac.get_value_for_voltage(voltage, vref)
                return {"jsonrpc": "2.0", "id": _id, "result": {"voltage": voltage, "value": value, "vref": vref}}

            if method == "read_adc":
                if self.stream_running:
                    raise RuntimeError("read_adc unavailable while streaming is active")
                ch = int(params["channel"])  # required
                differential = bool(params.get("differential", False))
                neg_channel = int(params.get("negChannel", 8))
                
                # Use the working ADS1256 class methods
                if differential and neg_channel < 8:
                    # Differential measurement
                    raw_value = self.adc.ADS1256_GetChannelValue(ch, neg_channel)
                else:
                    # Single-ended measurement
                    raw_value = self.adc.ADS1256_GetChannelValue(ch)
                
                # Calculate voltage using the working formula
                gain = int(params.get("gain", 1))
                voltage = (raw_value * 5.0 / 0x7fffff) / gain
                
                ret = {
                    "channel": ch,
                    "negChannel": neg_channel if differential and neg_channel < 8 else None,
                    "differential": differential,
                    "buffered": bool(params.get("buffered", False)),
                    "raw": raw_value,
                    "voltage": voltage,  # Return voltage in volts, not mV
                    "gain": gain,
                    "drate": float(params.get("drate", 10.0)),
                    "ts": time.time()
                }
                return {"jsonrpc": "2.0", "id": _id, "result": ret}

            if method == "read_adc_defined":
                if self.stream_running:
                    raise RuntimeError("read_adc_defined unavailable while streaming is active")
                
                # Use the working ADS1256 GetDefined method
                definition = params.get("definition", [])
                results = self.adc.ADS1256_GetDefined(definition)
                
                return {"jsonrpc": "2.0", "id": _id, "result": {"channels": results}}

            if method == "start_stream":
                # params: { streamId: str, mode:"round_robin", channels: [{ch, differential, neg, gain, drate, buffered}] }
                p = params
                if not isinstance(p.get("channels"), list) or not p.get("channels"):
                    raise ValueError("channels list required")
                requested_cfg = {
                    "streamId": p.get("streamId") or "default",
                    "channels": p["channels"],
                    "mode": p.get("mode", "round_robin"),
                }
                if self.stream_running:
                    try:
                        # Idempotent: if same config, acknowledge
                        if json.dumps(requested_cfg, sort_keys=True) == json.dumps(self.stream_cfg or {}, sort_keys=True):
                            return {"jsonrpc": "2.0", "id": _id, "result": {"ok": True}}
                    except Exception:
                        pass
                    # Different config: stop current stream and restart
                    self.stream_running = False
                    t = self.stream_thread
                    if t and t.is_alive():
                        t.join(timeout=1.0)
                    self.stream_thread = None
                    self.stream_cfg = None
                # Start with requested config
                self.stream_cfg = requested_cfg
                self.stream_running = True
                self.stream_thread = threading.Thread(target=self._stream_loop, daemon=True)
                self.stream_thread.start()
                return {"jsonrpc": "2.0", "id": _id, "result": {"ok": True}}

            if method == "stop_stream":
                self.stream_running = False
                t = self.stream_thread
                if t and t.is_alive():
                    t.join(timeout=1.0)
                self.stream_thread = None
                self.stream_cfg = None
                return {"jsonrpc": "2.0", "id": _id, "result": {"ok": True}}

            raise ValueError("Method not found")
            
        except Exception as e:
            log.error(f"Request error: {e}")
            return {"jsonrpc": "2.0", "id": _id, "error": {"code": -32000, "message": str(e)}}

    def _notify_stream_sample(self, sample: Dict[str, Any]) -> None:
        # Unsolicited event for stream samples
        msg = {"jsonrpc": "2.0", "method": "stream_sample", "params": sample}
        sys.stdout.write(json.dumps(msg) + "\n")
        sys.stdout.flush()

    def _stream_loop(self) -> None:
        cfg = self.stream_cfg or {}
        stream_id = cfg.get("streamId", "default")
        channels = cfg.get("channels", [])
        seq = 0
        # Cache last written register state to avoid redundant writes
        last_cfg: Dict[str, Any] = {"ch": None, "neg": None, "gain": None, "drate": None, "buffered": None, "differential": None}
        # Ensure hardware initialized before streaming
        try:
            self.adc._ensure_init()
        except Exception as e:
            self._notify_stream_sample({
                "streamId": stream_id,
                "error": str(e),
                "ts": time.time(),
            })
            return
        while self.stream_running:
            for ch_cfg in channels:
                if not self.stream_running:
                    break
                try:
                    ch = int(ch_cfg.get("ch"))
                    differential = bool(ch_cfg.get("differential", False))
                    neg = int(ch_cfg.get("neg", 8))
                    gain = int(ch_cfg.get("gain", 1))
                    drate = float(ch_cfg.get("drate", 10.0))
                    buffered = bool(ch_cfg.get("buffered", False))

                    # dynamic timeout from drate
                    dyn_timeout = max(0.1, (3.0 / float(drate)) + 0.01)

                    # Configure only when changed (reduces bus traffic)
                    if not (
                        last_cfg["ch"] == ch and
                        last_cfg["neg"] == (neg if differential else 8) and
                        last_cfg["gain"] == gain and
                        last_cfg["drate"] == drate and
                        last_cfg["buffered"] == buffered and
                        last_cfg["differential"] == differential
                    ):
                        with self.rm.lock:
                            self.adc._configure(ch, gain, buffered, drate, differential, neg)
                            last_cfg = {
                                "ch": ch,
                                "neg": neg if differential else 8,
                                "gain": gain,
                                "drate": drate,
                                "buffered": buffered,
                                "differential": differential,
                            }

                    status_reg_val = None
                    if bool(ch_cfg.get("debugStatus", False)):
                        try:
                            status_reg_val = self.adc._read_reg(self.adc.REG_STATUS)
                            log.info(f"[stream {stream_id}] STATUS=0x{status_reg_val:02X} BUFEN={(status_reg_val>>1)&1} ACAL={(status_reg_val>>2)&1}")
                        except Exception as e:
                            log.warning(f"[stream {stream_id}] STATUS readback failed: {e}")

                    # initial DRDY and SYNC/WAKEUP
                    if not self.adc._wait_drdy(timeout_s=dyn_timeout):
                        raise TimeoutError("initial DRDY timeout")
                    with self.rm.lock:
                        GPIO.output(self.adc.cfg.adc_cs_pin, GPIO.LOW)
                        try:
                            self.rm.spi.writebytes([self.adc.CMD_SYNC])
                            time.sleep(0.0002)
                            self.rm.spi.writebytes([self.adc.CMD_WAKEUP])
                        finally:
                            GPIO.output(self.adc.cfg.adc_cs_pin, GPIO.HIGH)

                    # Discard first conversion
                    if not self.adc._wait_drdy(timeout_s=dyn_timeout):
                        raise TimeoutError("discard DRDY timeout")
                    with self.rm.lock:
                        GPIO.output(self.adc.cfg.adc_cs_pin, GPIO.LOW)
                        try:
                            self.rm.spi.writebytes([self.adc.CMD_RDATA])
                            _ = self.rm.spi.readbytes(3)
                        finally:
                            GPIO.output(self.adc.cfg.adc_cs_pin, GPIO.HIGH)

                    # Valid conversion
                    if not self.adc._wait_drdy(timeout_s=dyn_timeout):
                        raise TimeoutError("valid conversion DRDY timeout")
                    with self.rm.lock:
                        GPIO.output(self.adc.cfg.adc_cs_pin, GPIO.LOW)
                        try:
                            self.rm.spi.writebytes([self.adc.CMD_RDATA])
                            data = self.rm.spi.readbytes(3)
                        finally:
                            GPIO.output(self.adc.cfg.adc_cs_pin, GPIO.HIGH)

                    if len(data) != 3:
                        raise RuntimeError("expected 3 bytes")
                    raw = (data[0] << 16) | (data[1] << 8) | data[2]
                    if raw & 0x800000:
                        raw -= 0x1000000
                    sample = {
                        "streamId": stream_id,
                        "seq": seq,
                        "channel": ch,
                        "negChannel": None if (not differential) else neg,
                        "differential": differential,
                        "buffered": buffered,
                        "raw": raw,
                        "gain": gain,
                        "drate": drate,
                        "ts": time.time(),
                    }
                    if status_reg_val is not None:
                        sample["statusReg"] = status_reg_val
                    self._notify_stream_sample(sample)
                    seq += 1
                except Exception as e:
                    self._notify_stream_sample({
                        "streamId": stream_id,
                        "error": str(e),
                        "ts": time.time(),
                    })
            # No pacing: stream at DRDY pace
            
    def run(self):
        log.info("Worker started; awaiting requests")
        while self.running:
            line = sys.stdin.readline()
            if not line:
                log.info("stdin closed; exiting")
                break
            s = line.strip()
            if not s:
                continue
            try:
                req = json.loads(s)
            except json.JSONDecodeError:
                self._write_response({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
                continue

            self.in_progress.set()
            try:
                resp = self.handle(req)
            finally:
                self.in_progress.clear()

            self._write_response(resp)
                
        self.cleanup()
        
    def cleanup(self):
        log.info("Cleaning up worker resources")
        try:
            # Stop streaming first
            self.stream_running = False
            if self.stream_thread and self.stream_thread.is_alive():
                self.stream_thread.join(timeout=1.0)
            
            # Cleanup ADC pins
            if hasattr(self, 'adc') and self.adc:
                self.adc.ADS1256_cleanup()
            
            # Cleanup SPI/GPIO resources
            self.rm.cleanup()
            
            # Final GPIO cleanup to ensure pins are freed
            GPIO.cleanup()
            
        except Exception as e:
            log.error(f"Cleanup error: {e}")
            # Force cleanup even if errors occur
            try:
                GPIO.cleanup()
            except:
                pass


def main():
    cfg = WorkerConfig()
    w = Worker(cfg)
    try:
        w.run()
    except KeyboardInterrupt:
        log.info("Received keyboard interrupt")
    except Exception as e:
        log.error(f"Worker error: {e}")
    finally:
        log.info("Shutting down worker...")
        w.cleanup()
        # Final cleanup to ensure pins are freed
        try:
            GPIO.cleanup()
        except:
            pass


if __name__ == "__main__":
    main()