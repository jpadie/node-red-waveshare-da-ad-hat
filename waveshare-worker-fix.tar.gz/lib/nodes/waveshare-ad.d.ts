export {};
//# sourceMappingURL=waveshare-ad.d.ts.map