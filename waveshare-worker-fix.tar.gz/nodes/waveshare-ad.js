"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
type: module;
const { workerManager } = require('./worker-manager.js');
module.exports = function (RED) {
    'use strict';
    function WaveshareADNode(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        // Handle node removal
        node.on('close', () => {
            // Only remove ref if we added one
            if (node.hasRef) {
                workerManager.removeRef();
                node.hasRef = false;
            }
        });
        // Handle incoming messages
        node.on('input', async function (msg) {
            // Add reference to worker manager on first use
            if (!node.hasRef) {
                workerManager.addRef();
                node.hasRef = true;
            }
            try {
                // Get configuration values with payload override priority
                const channel = parseInt(msg.payload?.channel) || parseInt(config.channel) || 0;
                const differential = (msg.payload?.differential ?? config.differential) ? true : false;
                const negChannel = parseInt(msg.payload?.negChannel) || parseInt(config.negChannel) || 1;
                const gain = parseInt(msg.payload?.gain) || parseInt(config.gain) || 1;
                const bufferedRaw = (msg.payload?.buffered ?? config.buffered);
                const buffered = (() => {
                    if (typeof bufferedRaw === 'boolean')
                        return bufferedRaw;
                    if (typeof bufferedRaw === 'number')
                        return bufferedRaw !== 0;
                    if (typeof bufferedRaw === 'string')
                        return ['1', 'true', 'on', 'yes'].includes(bufferedRaw.toLowerCase());
                    return false;
                })();
                // Accept overrides from payload or top-level msg, then fall back to node config
                const drate = parseFloat((msg.payload && msg.payload.drate) ?? msg.drate) || parseFloat(config.drate) || 10.0;
                // Debug: Log configuration values
                node.log(`ADC Node Config - channel: ${channel}, ${differential ? `- channel: ${negChannel}, ` : ''}gain: ${gain}, buffered: ${buffered}, drate: ${drate} (diff: ${differential})`);
                // Validate inputs
                if (channel < 0 || channel > 7) {
                    throw new Error('Channel must be between 0 and 7');
                }
                if (differential) {
                    if (negChannel < 0 || negChannel > 7) {
                        throw new Error('Negative channel must be between 0 and 7');
                    }
                    if (negChannel === channel) {
                        throw new Error('Positive and negative channels must differ');
                    }
                }
                if (![1, 2, 4, 8, 16, 32, 64].includes(gain)) {
                    throw new Error('Gain must be 1, 2, 4, 8, 16, 32, or 64');
                }
                if (![2.5, 5, 10, 15, 25, 30, 50, 60, 100, 500, 1000, 2000, 3750, 7500, 15000, 30000].includes(drate)) {
                    throw new Error('Invalid data rate');
                }
                // Send request to worker using new readADC method
                const result = await workerManager.readADC(channel, {
                    gain: gain,
                    drate: drate,
                    differential: differential,
                    negChannel: negChannel,
                    buffered: buffered
                });
                // Update message with enhanced result
                msg.payload = {
                    success: true,
                    channel: result.channel,
                    raw: result.raw,
                    voltage_mv: result.mV,
                    voltage_v: result.mV / 1000,
                    config: result.config
                };
                // Update node status
                node.status({
                    fill: 'green',
                    shape: 'dot',
                    text: `${result.config.differential ? `Ch${result.channel}-Ch${result.config.negChannel}` : `Ch${result.channel}`}: ${result.mV.toFixed(2)}mV`
                });
                node.send(msg);
            }
            catch (error) {
                const errorMessage = error?.message || 'Unknown error';
                node.error(`ADC operation failed: ${errorMessage}`, msg);
                // Update message with error
                msg.payload = {
                    success: false,
                    error: errorMessage,
                    timestamp: new Date().toISOString()
                };
                // Update node status
                node.status({
                    fill: 'red',
                    shape: 'ring',
                    text: `Error: ${errorMessage}`
                });
                node.send(msg);
            }
        });
        // Initial status
        node.status({
            fill: 'grey',
            shape: 'ring',
            text: 'Ready'
        });
    }
    RED.nodes.registerType('waveshare-ad', WaveshareADNode);
};
//# sourceMappingURL=waveshare-ad.js.map