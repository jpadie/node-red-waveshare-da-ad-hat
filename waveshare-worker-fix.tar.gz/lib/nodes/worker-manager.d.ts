import { WorkerRequest, WorkerManager as IWorkerManager } from '../../types/node-red.js';
import { EventEmitter } from 'events';
declare class WorkerManager extends EventEmitter implements IWorkerManager {
    private worker;
    private requestQueue;
    private inFlight;
    private isProcessing;
    private correlationId;
    private config;
    private refCount;
    private stdoutBuffer;
    private lingerTimer;
    private lingerMs;
    private stopping;
    private stoppingPromise;
    constructor(config: any);
    /**
     * Add a reference to this worker manager
     */
    addRef(): void;
    /**
     * Remove a reference from this worker manager
     */
    removeRef(): void;
    /**
     * Start the Python worker process
     */
    private startWorker;
    /**
     * Stop the Python worker process
     * (3) Don't null the ref before we may force-kill
     */
    private stopWorker;
    /**
     * Handle output from the Python worker (5)
     */
    private handleWorkerOutput;
    /**
     * Handle a response from the worker
     */
    private handleWorkerResponse;
    /**
     * Process the next request in the queue
     */
    private processNextRequest;
    /**
     * Send a request to the worker
     * (4) Start worker unconditionally if not running; refCount is lifecycle, not a hard gate
     */
    request<T>(request: Omit<WorkerRequest, 'id'>): Promise<T>;
    /**
     * Read ADC channel and return converted result with config
     */
    readADC(channel: number, options?: {
        gain?: number;
        drate?: number;
        differential?: boolean;
        negChannel?: number;
        buffered?: boolean;
    }): Promise<{
        channel: number;
        raw: number;
        mV: number;
        config: {
            vref: number;
            pga: number;
            sps: number;
            buffered: boolean;
            differential: boolean;
            negChannel?: number | null;
            timestamp: string;
        };
    }>;
    /**
     * Write DAC channel with voltage (converts to raw 16-bit value)
     */
    writeDAC(channel: number, voltage: number): Promise<void>;
    /**
     * Read multiple ADC channels based on definition
     */
    readADCDefined(definition: Array<{
        channel: number;
        differential?: boolean;
        'neg-channel'?: number;
        buffered?: boolean;
        SPS?: number;
        gain?: number;
    }>): Promise<{
        channels: Array<{
            channel: number;
            differential: boolean;
            negChannel?: number | null;
            buffered: boolean;
            sps: number;
            gain: number;
            raw: number;
            voltage: number;
        }>;
    }>;
    /**
     * Send a ping request to check if worker is alive
     */
    ping(): Promise<boolean>;
    /**
     * Check if the worker is connected
     * (7) Use exitCode instead of .killed
     */
    isConnected(): boolean;
    /**
     * Close the worker manager
     */
    close(): void;
    /**
     * Reject all pending requests
     */
    private rejectAllPending;
    /**
     * Log a message (11) separate log levels
     */
    private log;
    private debug;
}
export declare const workerManager: WorkerManager;
export {};
//# sourceMappingURL=worker-manager.d.ts.map