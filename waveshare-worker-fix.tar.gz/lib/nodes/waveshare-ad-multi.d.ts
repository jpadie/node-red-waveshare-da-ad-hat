export {};
//# sourceMappingURL=waveshare-ad-multi.d.ts.map